/*
SQLyog Ultimate v10.00 Beta1
MySQL - 5.6.12-log : Database - ssrahman_mainlibrary
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`ssrahman_mainlibrary` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `ssrahman_mainlibrary`;

/*Table structure for table `admin` */

DROP TABLE IF EXISTS `admin`;

CREATE TABLE `admin` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `fullname` varchar(20) DEFAULT NULL,
  `adminemail` varchar(20) DEFAULT NULL,
  `username` varchar(10) DEFAULT NULL,
  `password` varchar(20) DEFAULT NULL,
  `updationdate` varchar(25) NOT NULL,
  `cpassword` varchar(25) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

/*Data for the table `admin` */

insert  into `admin`(`id`,`fullname`,`adminemail`,`username`,`password`,`updationdate`,`cpassword`) values (1,'seamuddin','seam@gmail.com','seam','123','11/28/2019 11:41:44 pm','123');

/*Table structure for table `authors` */

DROP TABLE IF EXISTS `authors`;

CREATE TABLE `authors` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `authorname` varchar(20) NOT NULL,
  `creationdate` varchar(25) NOT NULL,
  `updatedate` varchar(25) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;

/*Data for the table `authors` */

insert  into `authors`(`id`,`authorname`,`creationdate`,`updatedate`) values (3,'Saimum','11-06-2019 03:47:27 am','11-06-2019 03:58:31 am'),(4,'JITU','11-06-2019 12:48:32 pm','11-06-2019 02:09:35 pm'),(10,'Technical','08-11-2019 06:08:32 am','11-10-2019 02:00:41 pm'),(11,'Info tech','08-11-2019 06:19:34 am',''),(12,'HOQ','08-11-2019 06:23:53 am',''),(13,'DIGI Tech','10-11-2019 02:01:00 pm',''),(14,'Sopnil','28-11-2019 09:50:14 pm','');

/*Table structure for table `books` */

DROP TABLE IF EXISTS `books`;

CREATE TABLE `books` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `bookname` varchar(100) NOT NULL,
  `catid` varchar(20) NOT NULL,
  `authorid` varchar(20) NOT NULL,
  `isbnnumber` varchar(20) NOT NULL,
  `bookprice` varchar(10) NOT NULL,
  `regdate` varchar(25) NOT NULL,
  `updatedate` varchar(25) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=48 DEFAULT CHARSET=latin1;

/*Data for the table `books` */

insert  into `books`(`id`,`bookname`,`catid`,`authorid`,`isbnnumber`,`bookprice`,`regdate`,`updatedate`) values (44,'Java programming','24','10','3456','124       ','08-11-2019 04:16:15 pm','10-11-2019 03:29:11 pm'),(46,'Physics 2','8','12','p22','120','10-11-2019 02:20:45 pm',NULL),(47,'Scripting With Python','24','12','S32','120','11-11-2019 12:50:35 am',NULL);

/*Table structure for table `category` */

DROP TABLE IF EXISTS `category`;

CREATE TABLE `category` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `categoryname` varchar(20) NOT NULL,
  `creationdate` varchar(25) NOT NULL,
  `updationtime` varchar(25) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=latin1;

/*Data for the table `category` */

insert  into `category`(`id`,`categoryname`,`creationdate`,`updationtime`) values (8,'Science','11-06-2019 03:26:54 am',NULL),(10,'Humanity','11-06-2019 03:27:24 am','11-08-2019 06:11:02 am'),(11,'Historical','11-06-2019 03:27:33 am','11-08-2019 06:06:38 am'),(24,'Computer Science','08-11-2019 06:19:21 am',NULL),(25,'Business Of Study','10-11-2019 02:00:14 pm',NULL);

/*Table structure for table `issuedbookdetails` */

DROP TABLE IF EXISTS `issuedbookdetails`;

CREATE TABLE `issuedbookdetails` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `bookid` int(10) NOT NULL,
  `studentid` varchar(20) NOT NULL,
  `issuesdate` varchar(30) NOT NULL,
  `returndate` varchar(25) DEFAULT NULL,
  `returnstatus` int(10) DEFAULT NULL,
  `fine` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

/*Data for the table `issuedbookdetails` */

insert  into `issuedbookdetails`(`id`,`bookid`,`studentid`,`issuesdate`,`returndate`,`returnstatus`,`fine`) values (5,44,'STU0008','10-11-2019 02:54:30 am','10-11-2019 02:56:57 am',1,230),(6,44,'STU0005','10-11-2019 02:39:29 pm',NULL,0,NULL),(8,46,'STU0005','10-11-2019 02:44:32 pm',NULL,0,NULL),(9,47,'STU0010','11-11-2019 12:52:04 am','11-11-2019 07:32:06 pm',1,2000),(10,44,'STU0014','17-11-2019 11:24:12 am','17-11-2019 11:25:02 am',1,200),(11,46,'STU0015','17-11-2019 11:34:48 am','17-11-2019 11:35:41 am',1,120);

/*Table structure for table `studata` */

DROP TABLE IF EXISTS `studata`;

CREATE TABLE `studata` (
  `sid` int(20) NOT NULL AUTO_INCREMENT,
  `stuid` varchar(20) NOT NULL,
  `sfname` varchar(10) NOT NULL,
  `slname` varchar(10) NOT NULL,
  `phone` varchar(12) NOT NULL,
  `email` varchar(30) NOT NULL,
  `password` varchar(20) NOT NULL,
  `cpassword` varchar(20) NOT NULL,
  `create_time` varchar(25) NOT NULL,
  `update_time` varchar(25) DEFAULT NULL,
  `cngpass_time` varchar(25) DEFAULT NULL,
  `status` varchar(2) DEFAULT NULL,
  PRIMARY KEY (`sid`)
) ENGINE=InnoDB AUTO_INCREMENT=54 DEFAULT CHARSET=latin1;

/*Data for the table `studata` */

insert  into `studata`(`sid`,`stuid`,`sfname`,`slname`,`phone`,`email`,`password`,`cpassword`,`create_time`,`update_time`,`cngpass_time`,`status`) values (43,'STU0005','Seam','uddin','01854422750','siam@gmail.com','123','123','10-31-2019 09:54:31 pm','11/08/2019 01:50:32 pm','11/08/2019 12:53:51 pm','1'),(44,'STU0008','khaled','mosaraf','01897248695','khaled@gmail.com','382246','382246','11-10-2019 02:25:36 am',NULL,NULL,'1'),(48,'STU0010','Ummey','salma','01732709710','salma@gmail.com','382249','382249','11-11-2019 12:37:33 am',NULL,'11/11/2019 12:44:25 am','1'),(49,'STU0014','Ahosan','Habib','1788196330','ahosanh325@gmail.com','382241','382241','11-17-2019 11:20:45 am',NULL,NULL,'1'),(52,'STU0015','seam','uddin','688474','seamuddin@gmail.com','123','123','11-17-2019 11:31:08 am',NULL,NULL,'1'),(53,'STU0016','seam','uddin','235677','usiam3001@gmail.com','123','123','11-27-2019 02:28:10 pm',NULL,NULL,NULL);

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
